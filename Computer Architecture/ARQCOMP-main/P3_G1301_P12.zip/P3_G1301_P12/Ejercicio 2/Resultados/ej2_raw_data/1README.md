README
Esta carpeta contiene los resultados sin procesar de la ejecución de cachegrind
para el ejercicio 2.
